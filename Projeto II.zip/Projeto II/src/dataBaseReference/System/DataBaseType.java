package dataBaseReference.System;

enum DataBaseType
   {
    MEMORY,
    MARIADB,
    INVALID
   }
